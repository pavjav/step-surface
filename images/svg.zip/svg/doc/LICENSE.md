
 svg and svg-extract -- Include and extract SVG pictures in LaTeX documents 
----------------------------------------------------------------------------

 Copyright (C) Philip Ilten <philten@cern.ch>, 2012-2016  
 Copyright (C) Falk Hanisch <hanisch.latex@outlook.com>, 2017-

----------------------------------------------------------------------------

 This work may be distributed and/or modified under the conditions of the
 LaTeX Project Public License, version 1.3c of the license. The latest
 version of this license is in http://www.latex-project.org/lppl.txt and 
 version 1.3c or later is part of all distributions of LaTeX 2005/12/01
 or later and of this work. This work has the LPPL maintenance status 
 "author-maintained". The current maintainer and author of this work
 is Falk Hanisch.

----------------------------------------------------------------------------

 Dieses Werk darf nach den Bedingungen der LaTeX Project Public Lizenz
 in der Version 1.3c, verteilt und/oder veraendert werden. Die aktuelle 
 Version dieser Lizenz ist http://www.latex-project.org/lppl.txt und 
 Version 1.3c oder spaeter ist Teil aller Verteilungen von LaTeX 2005/12/01 
 oder spaeter und dieses Werks. Dieses Werk hat den LPPL-Verwaltungs-Status 
 "author-maintained", wird somit allein durch den Autor verwaltet. Der 
 aktuelle Verwalter und Autor dieses Werkes ist Falk Hanisch.

----------------------------------------------------------------------------
